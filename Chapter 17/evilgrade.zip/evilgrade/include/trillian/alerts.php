<trillian>
	<alert type="minor" uid="<%RND2%>" title="Trillian 6 for Windows!" description="<%DESCRIPTION%>" url="http://www.ceruleanstudios.com/trilliancriticalupdate<%RND1%>.exe"/>
</trillian>


