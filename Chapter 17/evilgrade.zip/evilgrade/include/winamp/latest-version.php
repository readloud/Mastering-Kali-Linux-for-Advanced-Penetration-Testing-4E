9.573
http://client.winamp.com/update/client/notice.php
